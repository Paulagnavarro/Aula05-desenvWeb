export default function CustomButton(){
    function handleClick() {
        alert("Você clicou aqui");
    }
    return (
        <button onClick= {handleClick}>
            Clique aqui
        </button>
    )
}