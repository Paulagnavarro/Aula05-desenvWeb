import logo from './logo.svg';
import './App.css';
import CustomButton from './CustomButton';
import AlertButton from './AlertButton';
import Gallery from './Gallery';


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <CustomButton/>
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        {/* <AlertButton message="Filme iniciado">
          Play no filme
        </AlertButton>
        <AlertButton message="Upload de imagem iniciado">
          Upload de imagem
        </AlertButton> */}
        <div className="toolbar-custom" onClick={() => {alert("Clicou toolbar")}}>
          <button onClick={() => alert('Playing')}>Play filme</button>
          <button onClick={() => alert('Uploading')}>Upload de imagem</button>
        </div>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <Gallery/>
      </header>
    </div>
  );
}

export default App;
